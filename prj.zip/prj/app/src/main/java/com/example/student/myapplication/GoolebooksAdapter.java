package com.example.student.myapplication;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by student on 28.05.2018.
 */

public class GoolebooksAdapter extends RecyclerView.Adapter<GoolebooksAdapter.WordViewHolder> {



    class WordViewHolder extends RecyclerView.ViewHolder {
        TextView wordItemView;
        Button search_button;
        Button edit_button;


        public WordViewHolder(View itemView) {
            super(itemView);
            wordItemView = (TextView) itemView.findViewById(R.id.word);
            search_button = (Button)itemView.findViewById(R.id.search_button);

        }
    }//viewholder

    private final LayoutInflater mInflater;
    Context mContext;
    ArrayList<data> lbooks;
    public GoolebooksAdapter(Context context, ArrayList<data> listofbooks) {
        lbooks=listofbooks;
        mInflater = LayoutInflater.from(context);
        mContext = context;

    }
    @Override
    public WordViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.items, parent, false);
        return new WordViewHolder(itemView);
    }//oncreate
    @Override
    public void onBindViewHolder(final WordViewHolder holder, int position) {
        data d=lbooks.get(position);
        final WordViewHolder h = holder;
        holder.wordItemView.setText(d.getCountryName());
        holder.search_button.setOnClickListener(
                new MyButtonOnClickListener(d)  {

                    @Override
                    public void onClick(View v ) {
                        Intent intent = new Intent(mContext, edit_book.class);
                        //start intent
                        intent.putExtra("datasent", getDat());
                        intent.putExtra("ip",holder.wordItemView.getText().toString());
                        mContext.startActivity(intent);




                    }
                });


    }//onbind
    @Override
    public int getItemCount() {
        // Placeholder so we can see some mock data.
        return (int) lbooks.size();
    }




}
