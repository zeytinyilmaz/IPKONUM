package com.example.student.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class edit_book extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_book);

        data uobj= getIntent().getParcelableExtra("datasent");
        TextView t1=findViewById(R.id.textView);
        t1.setText("IP adresinin bulunduğu\nÜlke Adı : "+uobj.getCountryName()+"\nÜlke Kodu : "+uobj.getCountryCode());


    }
}
